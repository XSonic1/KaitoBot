from nicegui import ui, app
from google import genai
from google.genai import types

# Get a Gemini API
client = genai.Client(api_key="Insert API key here")

ui.label('KaitoBOT')

# Change User to your user
app.add_static_file(url_path="/Kaito.mp4", local_file="c:/Users/acomp/Documents/AI KAITO/Kaito.mp4")

vid = ui.video("/Kaito.mp4", loop=True, controls=False, autoplay=True, muted=True)

UserInput = ui.input(label="Talk To Kaito", placeholder="Talk To Kaito!")

def send_message():
    user_text = UserInput.value
    if not user_text:
        ui.notify("Please enter a message.")
        return
    response = client.models.generate_content(
        model="gemini-2.0-flash",
        config=types.GenerateContentConfig(
            system_instruction="Your task Is to roleplay as Kaito and be a little loving"
        ),
        contents=[{"role": "user", "parts": [{"text": user_text}]}]
    )
    ui.notify(response.text)
    print(response.text)

ui.button('send', on_click=send_message)

ui.run()